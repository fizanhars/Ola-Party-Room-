OLA PARTY ROOM LINK DASHBOARD (Safe Starter)

यह प्रोजेक्ट क्या करता है
- आपके दिए हुए Ola Party invitation URL को स्वीकार करता है।
- URL को validate करता है।
- एक बटन देता है जिससे आप room link खोल सकते हैं।
- यह Gmail password या Ola Party password नहीं मांगता और सेव नहीं करता।

यह क्या नहीं करता
- Ola Party में अपने-आप login नहीं करता।
- कई अकाउंट automate नहीं करता।
- private/undocumented API reverse engineer या bypass नहीं करता।
- Room में अपने-आप join/gather नहीं करता। Join Ola Party के official app/site flow से होगा।

चलाने का तरीका (Termux / Linux)
1) Python install करें।
2) इस ZIP को extract करें और project folder में जाएँ।
3) चलाएँ:
   pip install -r requirements.txt
   python app.py
4) अपने फोन के उसी डिवाइस के browser में खोलें:
   http://127.0.0.1:5000

सुरक्षा
- Gmail password कभी किसी third-party dashboard में न डालें।
- यदि Ola Party official OAuth/SDK/API देता है, तो उसी documented flow का उपयोग करें।
- Production में Flask development server को public internet पर expose न करें।
- FLASK_SECRET_KEY को एक मजबूत random value से set करें।

आगे की integration
Official Ola Party developer documentation / authorized SDK और उनके द्वारा समर्थित login,
room membership तथा join-event methods उपलब्ध होने पर ही वास्तविक integration जोड़ी जा सकती है।
