from flask import Flask, render_template, request, redirect, url_for, flash
from urllib.parse import urlparse
import os

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "change-this-before-deploying")

def valid_http_url(value: str) -> bool:
    try:
        parsed = urlparse(value.strip())
        return parsed.scheme in ("http", "https") and bool(parsed.netloc)
    except Exception:
        return False

@app.get("/")
def home():
    return render_template("index.html", room_url="")

@app.post("/open-room")
def open_room():
    room_url = request.form.get("room_url", "").strip()
    if not valid_http_url(room_url):
        flash("Please enter a valid http:// or https:// room invitation URL.", "error")
        return redirect(url_for("home"))
    # The page opens the user-provided invite URL. It does not log in,
    # automate accounts, scrape private APIs, or collect passwords.
    return render_template("open_room.html", room_url=room_url)

if __name__ == "__main__":
    # Local-only by default. Do not expose the development server to the internet.
    app.run(host="127.0.0.1", port=5000, debug=False)
